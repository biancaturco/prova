export interface Pizzas{
  id: string
  nome: string
  descricao: string
  estimativa: string
  valor: string
  image: string
}
