export class Forms {

  constructor(
    public id: number,
    public nome: string,
    public email: string,
    public assunto: string,
    public mensagem: string,
    public telefone?: string,
  ) { }

}
